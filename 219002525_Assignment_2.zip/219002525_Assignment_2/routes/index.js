const router = require('express').Router();

const students = [
    {
        name: "JUSTICE ANDOH",
        DOB: "12/04/1982",
        program: "BSC MIS",
        level: "200",
        image:"/images/m1.jpg"
    },
    {
        name: "KOFI ANDOH",
        DOB: "12/20/1990",
        program: " IT LAW",
        level: "200",
        image:"/images/m2.jpg"
    },
    {
        name: "JUNIOR ANDOH",
        DOB: "29/20/1995",
        program: "BSC BANKING & FINANCE",
        level: "200",
        image:"/images/m3.jpg"
    },
    {
        name: "JUSICE KOFI ANDOH ",
        DOB: "09/10/1987",
        program: "BSC PUBLIC ADMINISTRATION",
        level: "200",
        image:"/images/m4.jpg"
    },
    {
        name: "KJ ANDOH",
        DOB: "12/06/1998",
        program: "BSC COMPUTER SCIENCE",
        level: "200",
        image:"/images/m5.jpg"
    }
]


router.get('/', (req, res)=>{
    res.render('home', {
        title:'Home',
        students
    })
});

router.get('/student/:id', (req, res)=>{
    const id = req.params.id;
    const student = students[id];
    res.render('student', {
        title: students[id].name,
        student
    })
});

module.exports = router;